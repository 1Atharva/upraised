import React from "react";
import Quiz from "./Components/Quiz/Quiz";
import Header from "./Components/Quiz/Header";

const App = () => {
  return <div className="container">
      <Header />
      <Quiz />
      

      
    </div>
  
};

export default App;
