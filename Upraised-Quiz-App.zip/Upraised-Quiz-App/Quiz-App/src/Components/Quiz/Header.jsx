import React from 'react'

const Header = () => {
  return (
    <div className='container'>
        <h1 className=' m-2 text-center text-3xl p-2 font-semibold'>Quiz App</h1>
    </div>
  )
}

export default Header